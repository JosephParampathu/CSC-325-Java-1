/*Name Joseph Parampathu
* Module: Module 4, Case 1
* Description: This program queries the user for the number of guests, and prints
Carly's motto with a border, the cost of the event, and whether the event is large or not using
executable sta9
9
tements and the public class "event" with the use of overloaded constructors
*/
//This imports the Scanner device so that the program can access user input
import java.util.Scanner;
//EventDemo program is a public program so it is accessible to outside programs
public class EventDemo
{
	public static void main(String[] args)
	{
		//Declares an event object to use default constructors
		//Declares an event object (an instance of the class Event in the main method
		Event firstEvent = new Event("A000", 0);
		Event secondEvent = new Event();
			//Executes carlysBanner Method from the CarlysEventPriceWithMethods
			CarlysEventPriceWithMethods.carlysBanner();
			//Exexutes default constructor to set event number and number of guests
			firstEvent.display();
			promptGuests(secondEvent);

	}
	public static Event promptGuests(Event secondEvent){
		//This initiates the variable we will be using
			boolean large;
			int numberGuests;
			String eventNumber;
			double price;
			int PRICE_PER_GUEST = 35;
			int LARGE_CUTOFF = 50;
			//This tells the system where to find information input by the user
	 		Scanner input = new Scanner(System.in);
			//The program queries the user to input the number of guests
	 		System.out.println("How many guests are attending? >> ");
			//The program takes the number input and sets it to a variable
	 		numberGuests = input.nextInt();
			input.nextLine();
			//The program queries the user to input the number of the Event
			System.out.println("What is the Event Number? >> ");
			//This program takes the String input and sets it to a variable
			eventNumber = input.nextLine();
			//This tells the system where to find information input by the user
			price = numberGuests * PRICE_PER_GUEST;
			//The program determines if this is a "large" event
			large = (numberGuests >= 50);
			//The program prints the number of guests attending
			System.out.println(numberGuests + " guests attending.");
			//The program prints the price per guest
			System.out.println(PRICE_PER_GUEST + " dollars per guest.");
			//The program prints the total price
			System.out.println(price + " dollars in total.");
			//The program lets the user know if the event is large or not
			System.out.println("Large Event (50 or more guests)? " + large);
			//The program displays the event number
			System.out.println("Your Event Number is: " + eventNumber);
			return secondEvent;
		}
	//a public method to set the Event number
  public static void setEventNumber(String eventNum)
  {
    String eventNumber = eventNum;
  }
  //a public method to set the number of guests
  public static void setGuests(int numGuests)
  {
    int numberGuests = numGuests;
  }
}
