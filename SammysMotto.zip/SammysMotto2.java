//This is SammysMotto2 it prints Sammys Motto with an "S" border
public class SammysMotto2
{
	public static void main(String[] arges)
	{
		//This prints a line of S's
      System.out.println("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
		//This prints Sammy's Motto
		System.out.println("SSammy's makes it fun in the sun.S");
		//This prints a line of S's
			System.out.println("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
	}
}
