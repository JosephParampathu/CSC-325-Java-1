//This is SammysMotto it displays Sammys Motto
public class SammysMotto
{
	public static void main(String[] arges)
	{
   //This prints Sammy's Motto
		System.out.println("Sammy's makes it fun in the sun.");
	}
}
