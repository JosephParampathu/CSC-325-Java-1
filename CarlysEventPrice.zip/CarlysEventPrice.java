import java.util.Scanner;
public class CarlysEventPrice
{
	public static void main(String[] arges)
	{
			int numberGuests;
			int PRICE_PER_GUEST = 35;
			int totalPrice;
			boolean large;
			Scanner input = new Scanner(System.in);
			System.out.print("How many guests are attending? >> ");
			numberGuests = input.nextInt();
			totalPrice = numberGuests * PRICE_PER_GUEST;
			large = (numberGuests >= 50);
      System.out.println("***********************************************");
			System.out.println("*Carly's makes the food that makes it a party.*");
      System.out.println("***********************************************");
			System.out.println(numberGuests + " guests attending.");
			System.out.println(PRICE_PER_GUEST + " dollars per guest.");
			System.out.println(totalPrice + " dollars in total.");
			System.out.println("Large Event (50 or more guests)? " + large);
	}
}
