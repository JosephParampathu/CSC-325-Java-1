import java.util.Scanner;
public class SammysRentalPrice
{
	public static void main(String[] arges)
	{
			int numberOfMinutes;
			int rentalCost;
			int rentalHours;
			int additionalMinutes;
			int RENTAL_HOURLY_RATE = 40;
			int RENTAL_ADDITIONAL_MINUTE = 1;
			Scanner input = new Scanner(System.in);
			System.out.println("How many minutes long was your rental? >> ");
			numberOfMinutes = input.nextInt();
			additionalMinutes = numberOfMinutes % 60;
			rentalHours = numberOfMinutes / 60;
			rentalCost = rentalHours * RENTAL_HOURLY_RATE + additionalMinutes * RENTAL_ADDITIONAL_MINUTE;
      System.out.println("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
			System.out.println("SSammy's makes it fun in the sun.S");
      System.out.println("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");
			System.out.println("Rented for " + rentalHours + " hours and " + additionalMinutes + " minutes.");
			System.out.println("Total rental cost is " + rentalCost);
	}
}
