//This is the CarlysMotto Program it displays Carly's Motto
public class CarlysMotto
{
	public static void main(String[] arges)
	{
		System.out.println("Carly's makes the food that makes it a party.");
	}
}
