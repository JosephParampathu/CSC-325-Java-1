//This is CarlysMotto2 Program it displays Carly's Motto with a border
public class CarlysMotto2
{
	public static void main(String[] arges)
	{
   //Prints a line of asterisks
      System.out.println("***********************************************");
   //Prints Carly's Motto
		System.out.println("*Carly's makes the food that makes it a party.*");
   //Prints a line of asterisks
      System.out.println("***********************************************");
	}
}
